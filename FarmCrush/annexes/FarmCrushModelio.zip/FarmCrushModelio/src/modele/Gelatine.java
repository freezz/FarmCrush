package modele;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("e2a6c254-a904-4bc9-8734-82bab61f1039")
public class Gelatine {
    @objid ("20705234-2ed9-46a1-a9fe-52449c312ef4")
    private int coucheNiveau;

    @objid ("f4813531-aceb-4de0-ab6c-b559ffe8c641")
    public void retirerCouche() {
    }

    @objid ("640bcad9-abf5-419a-9f0e-28fd13095f01")
    public int getCoucheGelatine() {
        // TODO Auto-generated return
        return 0;
    }

}
