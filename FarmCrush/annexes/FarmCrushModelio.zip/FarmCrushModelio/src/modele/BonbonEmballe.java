package modele;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("0a5670b1-1333-4b90-b8f9-6acc78240dcb")
public class BonbonEmballe extends Bonbon {
    @objid ("6d6e5237-8ce6-4048-a880-011433430c91")
    public static int getValeur() {
        // TODO Auto-generated return
        return 0;
    }

    @objid ("9da143e6-c8f5-4dc1-a067-44fe24be57cd")
    public void destruction(final Grille g) {
    }

    @objid ("04f9f59c-20d0-46c1-9fdf-9d124e763f2e")
    public boolean interagir(final Grille g) {
        // TODO Auto-generated return
        return false;
    }

}
