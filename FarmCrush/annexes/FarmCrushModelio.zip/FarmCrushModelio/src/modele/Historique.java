package modele;

import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("e742cf30-6f47-4a5a-8173-7eef5920a4f6")
public class Historique {
    @objid ("56a4823d-7d8f-45e4-b3d4-db513d6cc3ad")
    public List<Coordonnee> coordonnees = new ArrayList<Coordonnee> ();

    @objid ("c0222df9-0b73-4a7c-bf7c-0a9b5f02559e")
    public Coordonnee getCoordonnee() {
        // TODO Auto-generated return
        return null;
    }

}
