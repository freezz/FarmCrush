package modele;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("65fb310d-be2d-4fde-b760-2dd527be6def")
public class BonbonRaye extends Bonbon {
    @objid ("7b52c18b-6194-4698-b7e7-eb9c443ff910")
    public static int getValeur() {
        // TODO Auto-generated return
        return 0;
    }

    @objid ("cb464b6a-7643-4b2f-b3f2-592933448871")
    public void destruction(final Grille g) {
    }

    @objid ("5aba2fef-632e-4b92-9440-7fe2944f24b2")
    public boolean interagir(final Grille g) {
        // TODO Auto-generated return
        return false;
    }

}
