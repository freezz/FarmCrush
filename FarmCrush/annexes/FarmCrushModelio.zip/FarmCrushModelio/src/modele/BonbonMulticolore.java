package modele;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("c19a49b0-896c-4da5-9d08-79985b43eab8")
public class BonbonMulticolore extends Bonbon {
    @objid ("4486b61d-12ca-42eb-8871-0927f25ff569")
    public static int getValeur() {
        // TODO Auto-generated return
        return 0;
    }

    @objid ("e20be99c-ed81-444e-b8a8-807d9785e3ec")
    public void destruction(final Grille g) {
    }

    @objid ("336d4390-339e-46c6-9589-34423ee2a2a6")
    public boolean interagir(final Grille g) {
        // TODO Auto-generated return
        return false;
    }

}
