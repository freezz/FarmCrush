package modele;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("10278397-0802-4bbc-a722-79a4b837ebe7")
public class Objectif {
    @objid ("4fec9ac7-d2d3-434b-962c-785c844ed570")
    private int scoreMax;

    @objid ("e1593721-b03e-4210-8af9-92e9e84d9e5f")
    private int gelatineRestante;

    @objid ("dddfd0bc-c8e5-46c7-82f5-7b02208fc659")
    private int nbCoupMax;

    @objid ("4fd60bf7-d243-4fb9-af0d-b69586f57476")
    private int nbRougeRestant;

    @objid ("efd576f3-c5d0-43d8-9164-4c288f7275fb")
    private int nbVioletRestant;

    @objid ("19ab102b-bcbb-4f3e-b139-8bf339cda5dc")
    private int nbVertRestant;

    @objid ("1e29d2d9-aa25-40e2-a8a1-608ef3cbea3d")
    private int nbJauneRestant;

    @objid ("2aaeadbe-0c82-4e07-bcaf-0ed37345230f")
    private int nbOrangeRestant;

    @objid ("356afbe6-d021-4134-b209-8d435aa470cd")
    private int nbBleuRestant;

    @objid ("a884ecf4-fd3a-4d78-9528-661b1570a063")
    public int nbRayeRestant;

    @objid ("3a25a6bf-eabb-48fa-9291-85ab074db1ba")
    public int nbEmballeRestant;

    @objid ("51fb5265-ccd7-4721-af1e-d19f8f0772f9")
    public int nbMultiRestant;

    @objid ("8cab92ae-440f-4887-bda9-95a4881fef70")
    public boolean estVerifier() {
        // TODO Auto-generated return
        return false;
    }

}
