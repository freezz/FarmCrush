package modele;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("943a89cd-60aa-487c-a126-684f001d74c7")
public class Coordonnee {
    @objid ("5d14c942-b68e-4e6c-8272-b6ce9039106d")
    private int x;

    @objid ("387ff8f6-da0d-4618-8e56-f805961e96b3")
    private int y;

    @objid ("768ef8fb-1f49-45ce-b37a-3349a5df54e1")
    public int getX() {
        // TODO Auto-generated return
        return 0;
    }

    @objid ("5daebcf7-927c-4f00-bd67-347757973899")
    public int getY() {
        // TODO Auto-generated return
        return 0;
    }

}
