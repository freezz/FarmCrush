package modele;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("0afbcf75-8749-4dd5-82fa-cfadd640620f")
public class Case {
    @objid ("7dd9c106-2dce-4a31-80a4-1dfadb269cba")
    public Gelatine gelatine;

    @objid ("f3204dcd-b9f4-4939-aaea-8daa0cde121e")
    public Bonbon bonbon;

    @objid ("70a0da5e-93bb-40b8-9695-8a993e2683b8")
    public Coordonnee coordonnee;

    @objid ("c11c354a-4f10-4ea6-938f-41dcd4363931")
    public void retirerContenu() {
    }

    @objid ("21157085-85dc-4733-b91e-9f5e81298847")
    public Bonbon getBonbon() {
        // TODO Auto-generated return
        return null;
    }

    @objid ("d2e3d9ef-daf2-4503-958d-a7c40538ba18")
    public int getCoordonee() {
        // TODO Auto-generated return
        return 0;
    }

    @objid ("cda4599d-6189-4f2d-b510-0e9d20726535")
    public Gelatine getGelatine() {
        // TODO Auto-generated return
        return null;
    }

}
