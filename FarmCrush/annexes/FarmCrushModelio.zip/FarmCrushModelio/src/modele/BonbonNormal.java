package modele;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("3e8169b7-f416-4598-88f5-1dcb25fa0423")
public class BonbonNormal extends Bonbon {
    @objid ("93af903f-8c1e-4617-bcd8-0913246f3aec")
    public boolean interagir(final Grille g) {
        // TODO Auto-generated return
        return false;
    }

    @objid ("8ea534b9-ad6a-4a0b-a887-5fac7b47af71")
    public static int getValeur() {
        // TODO Auto-generated return
        return 0;
    }

    @objid ("aaccefb9-6647-4243-a9e6-d95c293b42ef")
    public void destruction(final Grille g) {
    }

}
