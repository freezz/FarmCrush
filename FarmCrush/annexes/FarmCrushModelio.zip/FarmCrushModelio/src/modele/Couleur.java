package modele;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("391e6103-00ca-49e0-902c-3efd263088a6")
public enum Couleur<T> {
    ROUGE,
    VERT,
    JAUNE,
    VIOLET,
    BLEU,
    ORANGE;
}
